const express = require('express');
const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const bcrypt = require('bcrypt');
const app = express();

app.use(express.json());

// Secret key for JWT signing
const secretKey = 'gfrgsfsefsfefsfsef';

// MySQL database connection configuration
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'company'
};

const connection = mysql.createConnection(dbConfig);

// Connect to the database
connection.connect(function (err) {
    if (err) {
        console.error('Error connecting to database: ' + err.stack);
        return;
    }
    console.log('Connected to the database');
});

// Joi schema for employee signup validation
const signupSchema = Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    gender: Joi.string().valid('male', 'female').required(),
    hobbies: Joi.string().required(),
    email: Joi.string().required(),
    password: Joi.string().min(8).max(20).required(),
    role: Joi.string().required()
});

// Function to generate JWT token
function generateToken(payload) {
    return jwt.sign(payload, 'gfrgsfsefsfefsfsef', { expiresIn: '2h' });
}

async function generateHashPassword(dataString) {
    try {
        const salt = await bcrypt.genSalt();
        return await bcrypt.hash(dataString, salt);
    } catch (error) {
        throw new Error(error);
    }
}
app.get('/employee', async (req, res) => {
    const token = req.headers.authorization;

    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
        const decodedToken = await decodeToken(token);

        if (decodedToken.role !== 'employee') {
            return res.status(403).json({ error: 'Forbidden' });
        }

        const employeeId = decodedToken.id;

        connection.query('SELECT * FROM employees WHERE id = ?', employeeId, (err, rows) => {
            if (err) {
                console.error('Error retrieving employee data:', err);
                res.status(500).json({ error: 'Internal server error' });
            }

            if (rows.length === 0) {
                return res.status(404).json({ error: 'Employee not found' });
            }

            const employeeData = rows[0];

            res.json({ data: employeeData });
        });
    } catch (err) {
        console.error('Error decoding token:', err);
        res.status(401).json({ error: 'Unauthorized' });
    }
});
// Route for employee signup
app.post('/signup', async (req, res) => {
    try {
        const { error, value } = signupSchema.validate(req.body);

        if (error) {
            res.status(400).json({ error: error.details[0].message });
            return;
        }

        const { firstName, lastName, gender, hobbies, role, email, password } = value;

        const emailData = await new Promise((resolve, reject) => {
            connection.query(`SELECT * FROM employees WHERE email = ? AND role = ?`, [email, role], (err, rows) => {
                if (err) {
                    console.error('Error fetching employee details:', err);
                    reject(err);
                }
                resolve(rows);
            });
        });

        if (emailData.length > 0) {
            res.json('Email Already exists');
            return;
        }

        const hashPass = await generateHashPassword(password);

        const employee = {
            first_name: firstName,
            last_name: lastName,
            gender,
            hobbies,
            role,
            email,
            password: hashPass
        };

        connection.query('INSERT INTO employees SET ?', employee, (err, rows) => {
            if (err) {
                console.error('Error storing employee details:', err);
                res.status(500).json({ error: 'Internal server error' });
                return;
            }

            const payload = {
                id: rows.insertId,
                firstName,
                lastName,
                gender,
                hobbies,
                role,
                email
            };

            // Generate the JWT token using the separate function
            const token = generateToken(payload);
            res.json({ token });
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/category', async (req, res) => {
    try {
        const { name } = req.body;

        const checkCategoryExistData = await checkCategoryExist(name);

        if (!checkCategoryExistData) {
            const payload = { name };

            connection.query('INSERT INTO category SET ?', payload, (err, rows) => {
                if (err) {
                    console.error('Error storing category details:', err);
                    res.status(500).json({ error: 'Internal server error' });
                    return;
                }

                res.json({ data: 'Category Created' });
            });
        } else {
            res.json({ data: 'Category Already Exists' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/department', async (req, res) => {
    try {
        const { name } = req.body;
        const duplicateData = await checkDepartmentExist(name);

        if (!duplicateData) {
            const payload = { name };

            connection.query('INSERT INTO department SET ?', payload, (err, rows) => {
                if (err) {
                    console.error('Error storing department details:', err);
                    res.status(500).json({ error: 'Internal server error' });
                    return;
                }

                res.json({ data: 'Department Created' });
            });
        } else {
            res.json({ data: 'Department Already Exists' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/management', async (req, res) => {

    const token = req.headers.authorization;
    const decodedTokenData = await decodeToken(token);

    if (decodedTokenData.role !== 'manager') {
        return res.status(403).json({ error: 'Forbidden' });
    }
    const { page, limit } = req.query;
    const offset = (page - 1) * limit;
    console.log(page, limit);
    const query = `
    SELECT m.*, e.first_name, e.last_name, c.name AS category_name, d.name AS department_name
    FROM management AS m
    INNER JOIN employees AS e ON m.emp_id = e.id
    INNER JOIN category AS c ON m.category_id = c.id
    INNER JOIN department AS d ON m.department_id = d.id
    LIMIT ?, 5
  `;

    connection.query(query, [offset, +limit], (err, rows) => {
        if (err) {
            console.error('Error retrieving management data:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        res.json({ data: rows });
    });
});

app.put('/management/:id', async (req, res) => {
    try {

        const token = req.headers.authorization;
        const { department_id, category_id, emp_id, salary, location } = req.body;
        const managementId = req.params.id;
        const decodedTokenData = await decodeToken(token);

        if (decodedTokenData.role !== 'manager') {
            return res.status(403).json({ error: 'Forbidden' });
        }
        const checkCategoryExistData = await checkCategoryExist(false, category_id);
        const checkDepartmentExistData = await checkDepartmentExist(false, department_id);

        if (checkCategoryExistData && checkDepartmentExistData) {
            const payload = {
                department_id,
                category_id,
                emp_id,
                salary,
                location
            };

            connection.query('UPDATE management SET ? WHERE id = ?', [payload, managementId], (err, rows) => {
                if (err) {
                    console.error('Error updating management details:', err);
                    res.status(500).json({ error: 'Internal server error' });
                    return;
                }

                res.json({ data: 'Management details updated successfully' });
            });
        } else {
            res.json({ data: 'Invalid category or department' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }

});

app.get('/query1', (req, res) => {
    const { page, limit } = req.query;
    const offset = (page - 1) * limit;
    console.log(page, limit);
    const query = `
    SELECT * FROM employees where id IN (select emp_id from management where location = '%i' and department_id = (select id from department where name = 'data'))
    limit ?, 5
  `;

    connection.query(query, [offset, +limit], (err, rows) => {
        if (err) {
            console.error('Error retrieving management data:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        res.json({ data: rows });
    });
});

app.get('/query2', (req, res) => {
    const { page, limit } = req.query;
    const offset = (page - 1) * limit;
    console.log(page, limit);
    const query = `
    SELECT * FROM employees where id IN (select emp_id from management where department_id = (select id from department where name = 'data'))
    ORDER BY id DESC 
    limit 0, 5
  `;

    connection.query(query, [offset, +limit], (err, rows) => {
        if (err) {
            console.error('Error retrieving management data:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        res.json({ data: rows });
    });
});

app.post('/manager/department', async (req, res) => {
    try {

        const token = req.headers.authorization;
        // console.log(token);
        const { department_id, category_id, e_id, salary, location, removeId } = req.body;
        const decodedTokenData = await decodeToken(token);
        console.log(decodedTokenData.role);
        if (decodedTokenData.role != 'manager') {
            return res.status(403).json({ error: 'Forbidden' });
        }
        if (removeId.length > 0) {
            removeId.forEach((ele) => {
                connection.query(`DELETE FROM management WHERE id = ?`, ele, (err, rows) => { });
            });
        }

        if (e_id.length > 0) {
            const checkCategoryExistData = await checkCategoryExist(false, category_id);
            const checkDepartmentExistData = await checkDepartmentExist(false, department_id);

            if (checkCategoryExistData) {
                if (checkDepartmentExistData) {
                    for (const element of e_id) {
                        const duplicateEmployee = await checkDuplicateEmployee(department_id, category_id, element);

                        if (!duplicateEmployee) {
                            const payload = {
                                department_id,
                                category_id,
                                emp_id: element,
                                salary,
                                location
                            };

                            connection.query('INSERT INTO management SET ?', payload, (err, rows) => {
                                if (err) {
                                    console.error('Error storing department details:', err);
                                    res.status(500).json({ error: 'Internal server error' });
                                    return;
                                }
                            });
                        } else {
                            res.json({ data: 'Employee Exist in department' });
                            return;
                        }
                    }

                    res.json({ data: 'Employee Added successfully' });
                }
            } else {
                res.json({ data: 'Category does not exist' });
            }
        } else {
            res.json({ data: 'Employee Removed Successfully' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

async function checkCategoryExist(name, id) {
    let data;
    if (name) {
        data = `name = '${name}'`;
    }
    if (id) {
        data = `id = '${id}'`;
    }
    const query = `SELECT * FROM category WHERE ${data}`;

    return new Promise((resolve, reject) => {
        connection.query(query, (err, rows) => {
            if (err) {
                console.error('Error:', err);
                reject(err);
            }

            if (rows.length > 0) {
                resolve(true);
            } else {
                resolve(false);
            }
        });
    });
}

async function checkDepartmentExist(name, id) {
    let data;
    if (name) {
        data = `name = '${name}'`;
    }
    if (id) {
        data = `id = '${id}'`;
    }

    return new Promise((resolve, reject) => {
        connection.query(`SELECT * FROM department WHERE ${data}`, (err, rows) => {
            if (err) {
                console.error('Error:', err);
                reject(err);
            }

            if (rows.length > 0) {
                resolve(true);
            } else {
                resolve(false);
            }
        });
    });
}

async function decodeToken(token) {
    try {
        const parts = token.split(' ');
        console.log(parts[1]);
        // return jwt.verify('Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjcsImZpcnN0TmFtZSI6InNoayIsImxhc3ROYW1lIjoic2hrIiwiZ2VuZGVyIjoibWFsZSIsImhvYmJpZXMiOiJnb29kIiwicm9sZSI6ImVtcGxveWVlIiwiZW1haWwiOiJhc2QyMTJAbWFpbGluYXRvci5jb20iLCJpYXQiOjE2ODc0MTE3NjB9.YCnbEhRwFpxT2-FTbUW0GKhqwdK2Ox2jSm-Af5Gxm74', 'gfrgsfsefsfefsfsef');
        return jwt.verify(parts[1], 'gfrgsfsefsfefsfsef');
    } catch (err) {
        throw err;
    }
}

async function checkDuplicateEmployee(dId, cId, eId) {
    try {
        return new Promise((resolve, reject) => {
            connection.query(
                `SELECT * FROM management WHERE department_id = ? AND category_id = ? AND emp_id = ?`,
                [dId, cId, eId],
                (err, rows) => {
                    if (err) {
                        console.error('Error:', err);
                        reject(err);
                    }

                    if (rows?.length > 0) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }
            );
        });
    } catch (err) {
        throw err;
    }
}

// Start the server and listen on port 3000
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
